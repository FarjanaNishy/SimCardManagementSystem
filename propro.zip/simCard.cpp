#include<bits/stdc++.h>
#include<iostream>
#include<fstream>
#include<stdlib.h>
#include <conio.h>
using namespace std;

class info
{
 private:
string name,address,pass;
int age;
 public:
    void get_info()
    {
        string a,b,p;
        int c;
        a=name;
        b=address;
        c=age;
        p=pass;
    }
    void show_info();
};

void info::show_info()
{
ofstream info;
ofstream login;
info.open("info.txt");
login.open("login.txt");
regester:

cout<<"Enter your name :"<<endl;
cin>>name;
info<<name<<" ";
cout<<"Enter your address:"<<endl;
cin>>address;

info<<address<<" ";
cout<<"Enter your age:"<<endl;
cin>>age;
info<<age<<" ";
if(age<15)
{
    cout<<"You are not eligible for using phone.....Try again later..!!!"<<endl;
    goto regester;
}

cout<<"Enter your password"<<endl;
cin>>pass;
info<<pass<<" ";
login<<pass<<" ";
int num,balance,n=1;
 freopen("nish.txt","r",stdin);
    do
    {
        cin>>num>>balance;
        cout<<"Your number :"<<num;
        info<<num;
        login<<num;
        n--;
    }
    while(n!=0);
}

void information_check()
{
    ifstream info;
    string name,address,pass;
    int age,num;
    freopen("info.txt","r",stdin);
    while(cin>>name>>address>>age>>pass>>num)
    {
        cout<<"Name:"<<name<<endl;
        cout<<"Address:"<<address<<endl;
        cout<<"Age:"<<age<<endl;
        cout<<"Password:"<<pass<<endl;
        cout<<"Sim Number:"<<num<<endl;
    }

}

void number_list()
{

    int num,balance;
    cout<<"Number List:"<<endl;
    freopen("nish.txt","r",stdin);
    while(cin>>num>>balance)
{
            cout<<num<<endl;

}
}
int searchnum()
{
    int num,balance,num2;
    cout<<"Enter the number you want to search.."<<endl;
     cin>>num2;
     int loc = 0;
      freopen("nish.txt","r",stdin);
    while(cin>>num>>balance){
        if(num==num2){
            cout<<"Number :"<<num<<" "<<"Balance :"<<balance<<endl;
            loc = 1;
            break;
        }
    }
    if(!loc)
        cout<<"Not found"<<endl;
        return 0;
}

int offer()
{
    ofstream offer;

    int tk,mb;
    string ch;

    offer.open("offer.txt");
    cout<<"Current offer :"<<endl;
    cout<<"Taka"<<"\t"<<"Megabite"<<endl;
    offer<<"10"<<"\t"<<"100"<<endl;
    cout<<"10"<<"\t"<<"100"<<endl;
    offer<<"20"<<"\t"<<"250"<<endl;
    cout<<"20"<<"\t"<<"250"<<endl;
    offer<<"50"<<"\t"<<"1000"<<endl;
    cout<<"50"<<"\t"<<"1000"<<endl;
    cout<<"Do you want to add more offer? "<<endl;
    cin>>ch;
    if(ch == "y")
    {
        cin>>tk>>mb;
        offer<<tk<<" "<<mb<<endl;;

    }
    return 0;
}

int helpcenter()
{
    int n;
    string sm;
    ofstream helpzone;
    cout<<"Do you have any problem ?? Yes or NO?"<<endl;
    char am;
    cin>>am;
    if(am=='n') exit(0);
    else if(am=='y'){
    cout<<"Type your number here!"<<endl;
    cin>>n;
    cout<<"Type your problem here!"<<endl;
    cin>>sm;
     helpzone.open("helpzone.txt");

    //cin.get(help,200);
    helpzone<<sm;
    helpzone<<" ";
    helpzone<<n;
    cout<<"We have submitted your number!"<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"We will give you feedback as soon as possible........."<< endl<< "*** Thank U *** ";
    }
    return 0;
}

int offercheck()
{
    int tk1,mb1;
    ofstream tk;
    tk.open("tk.txt");
    cout<<"Current offer:"<<endl;
    freopen("offer.txt","r",stdin);
     cout<<"Taka"<<"\t"<<"Megabite"<<endl;
    while(cin>>tk1>>mb1)
    {
     cout<<tk1<<"\t"<<mb1<<endl;
     tk<<tk1<< endl;
    }
return 0;
    }

int balancecheck()
{
    int num,balance,num2;
    cout<<"Enter the number....."<<endl;

     cin>>num2;
     int loc = 0;
      freopen("nish.txt","r",stdin);
    while(cin>>num>>balance){
        if(num==num2){

            cout<<"Balance :"<<balance<<endl;
            loc = 1;
           break;
        }
    }
    if(!loc)
        cout<<"Ooopss....!!!  Enter correct number...."<<endl;
}
void logo(){
    cout<<"                           /*****\\"<<endl;
   cout<<" /*****\\                   \\*****/                         /*****\\"<<endl;
   cout<<" \\*****/                    |***|                          \\*****/"<<endl;
   cout<<"  |***|              /******|***|******\\                    |***|"<<endl;
   cout<<"  |***|              |******|***|******|                    |***|"<<endl;
   cout<<"  |***|  |*****             |***|            /***\\          |***|"<<endl;
   cout<<"  |***|  |*******           |***|           /*****\\         |***|"<<endl;
   cout<<"  |***|  |********          |***|          /***@***\\        |***|"<<endl;
   cout<<"  |***|  |*******           |***|         /***   ***\\       |***|"<<endl;
   cout<<"  |***|  |*****             |***|        /*** ___ ***\\      |***|"<<endl;
   cout<<"  |***|  |*******           |***|       /***/     \\***\\     |***|"<<endl;
   cout<<"  |***|  |********          |***|      /***/       \\***\\    |***|"<<endl;
   cout<<"  |***|  |*******           |***|     /***/         \\***\\   |***|"<<endl;
   cout<<"  |***|__|*****___________**|***|**__/***/___________\\***\\__|***|"<<endl;
   cout<<"  |*************************************************************|"<<endl;
   cout<<"  |*************************************************************|"<<endl;
   cout<<"                           /*****\\"<<endl;
   cout<<"                           \\*****/"<<endl;
   cout<<"Welcome to IUBAT University"<<endl;
   cout<<"Name : Farjana Ema Nishy"<<endl;
   cout<<"ID   : 18103248"<<endl;
}

int main()
{
    logo();
    char again;
    //getchar();
    int choise;
    string pass;
    system("color FC");
    cout<<endl <<endl;
    //nishy:
    cout<< "\t \t \t \t \t  Welcome to Tele-Talk"<<endl<<endl;
    cout<<"1.Administator"<<endl;
    cout<<"2.User."<<endl;
    //cout<<"If you don't want to continue, please type 3"<<endl;
    cout<<"Ender Your choise :"<<endl;
    cin>>choise;
    if(choise==1)
    {
        cout<<"Enter your password:"<<endl;
        manu:
        int pass=7;
        string nish="";
        char ch;
        ch=_getch();
        while(pass--){
            nish+=ch;
            cout<<"*";
            ch=_getch();
        }
        cout<<endl;
       if(nish=="iubat18")
    {

        cout<<"1.Number list:"<<endl;
        cout<<"2.Check any number:"<<endl;
        cout<<"3.Add offer:"<<endl;
        cout<<"4.User Reviews !! "<<endl;
        cout<<"Enter your choice :(1-5)"<<endl;
        int ch;
        cin>>ch;
        switch(ch)
        {
        case 1:
           number_list();
            break;
        case 2:
            searchnum();
            break;
        case 3:
          offer();
             break;
        case 4:
             number_list();
             break;

        }
    }
    else
       {
        cout<< "Wrong password !!!!!!!" <<endl<<"Enter correct password"<<endl;
        goto manu;
        }
    }
    else
    {
        string ch2;
        system("color 71");
        cout<<"\t \t \t \t \t Welcome to Tele_Talk"<<endl;
        cout<<"1.Regestered yourself: "<<endl;
        cout<<"2.Log in your account:"<<endl;
        cout<<"Enter your choice:"<<endl;
        cin>>ch2;

        if(ch2=="1")
        {
         info obj;
string choise;
    cout<<"Do you want to registered ??"<<endl;
    cout<<"If your answer positve  ,press y"<<endl;
    cin>>choise;
    if(choise=="y")
    {
    obj.get_info();
    obj.show_info();
    }
        }
        else
        {
        cout<<"Enter your password and phone number"<<endl;
        string p1,pass;
        int n1,num,n=1;
        cin>>p1>>n1;

    if(n1==110001 && p1=="121"){


        cout<<"Log in Successfully....."<<endl;
        cout<<"1.Check balance :"<< endl;
        cout<<"2.Check offer:"<<endl;
        cout<<"3.Check information :"<<endl;
        cout<<"4.Help Center:"<<endl;

        int ch1;
        cout<<"Enter your choice :"<<endl;
        cin >> ch1;
      if(ch1==1){
            balancecheck();
      }

        else if(ch1==2){
        offercheck();
           }
  else if(ch1==3)
  {
       information_check();
  }
      else if(ch1==4){

          helpcenter();
      }
       else{
            cout<<"Out of service..........!!"<<endl;

       }
        }
        else
        {
            cout<<"Enter correct password .......!!!";        }
    }
    }
   // if(choise==3) exit(0);


    return 0;

    }

